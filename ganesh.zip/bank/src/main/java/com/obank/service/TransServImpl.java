package com.obank.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.obank.dao.TransDao;
import com.obank.model.Transactions;

@Service("TransService")
public class TransServImpl implements TransServIntf {
	 @Autowired
	  public TransDao transDao;
	

	public List<Transactions> getTrans(Date fromdate, Date todate) {
		 List<Transactions>  list = transDao.getTrans( fromdate,  todate);
		  return list;
	}


	public List<Transactions> getLastFiveTrans() {
		 List<Transactions>  list = transDao.getLastFiveTrans();
		return list;
	}


	public void enterPassword(String email, String new_password, String confirm_password) {
		transDao.enterPassword(email,new_password,confirm_password);
		
	}
	 

}
