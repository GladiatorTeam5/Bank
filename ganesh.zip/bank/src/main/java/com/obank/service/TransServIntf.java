package com.obank.service;

import java.util.Date;
import java.util.List;

import com.obank.model.Transactions;

public interface TransServIntf {
	public List<Transactions> getTrans(Date fromdate, Date todate);

	public List<Transactions> getLastFiveTrans();
	public void enterPassword(String email,String new_password, String confirm_password);


}
