package com.obank.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.obank.model.Transactions;

@Repository("TransDao")
public class TransDaoImpl implements TransDao {

	public List<Transactions> getTrans(Date fromdate, Date todate) {
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  
		  @SuppressWarnings("unchecked")
			Query query =  em.createQuery("SELECT u FROM  Transactions u where u.dot between :fromdate and :todate");
		    query.setParameter("fromdate", fromdate);
		    query.setParameter("todate", todate);
		    @SuppressWarnings("unchecked")
			List<Transactions> trans = query .getResultList();
		  em.close();
		  return  trans;
		 
	}

	public List<Transactions> getLastFiveTrans() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  
		  @SuppressWarnings("unchecked")
		  Query query =  em.createQuery("SELECT u FROM  Transactions u where rownum<=3 order by dot ");
		    
		    @SuppressWarnings("unchecked")
			List<Transactions> trans = query .getResultList();
		    System.out.println("trans:"+trans);
		 // em.close();
		  return  trans;
	}

	public boolean enterPassword(String email, String new_password, String confirm_password) {

		  boolean flag=false;
		  EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	 
		  Query q = em.createQuery("UPDATE Login s SET s.lpwd=:new_password WHERE s.email=:email ");
		 
		  q.setParameter("email", email);
		  q.setParameter("new_password", new_password);
		 // q.setParameter("confirm_password", confirm_password);
		  em.getTransaction().begin();
		  System.out.println(email);
		  System.out.println(new_password);
		  int r = q.executeUpdate();
		  em.getTransaction().commit();
		  em.close();
		 
		  if(r>0)
			flag=true;
		  return flag;
		
	}
	
}
