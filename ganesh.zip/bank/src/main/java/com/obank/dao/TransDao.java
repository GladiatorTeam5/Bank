package com.obank.dao;

import java.util.Date;
import java.util.List;

import com.obank.model.Transactions;

public interface TransDao {
	public List<Transactions> getTrans(Date fromdate, Date todate);

	public List<Transactions> getLastFiveTrans();

	public boolean enterPassword(String email, String new_password, String confirm_password);

}
