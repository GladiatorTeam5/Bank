package com.obank.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.obank.mail.SendMail;
import com.obank.model.Transactions;
import com.obank.service.TransServIntf;

@Controller("AccountController")
public class AccountController {
	
	@Autowired
	 public TransServIntf transService;
	

	@RequestMapping(value = "/statement", method = RequestMethod.GET)
	  public ModelAndView showtrans(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("statement");
	    return mav;
	  }
	@RequestMapping(value = "/admin_login", method = RequestMethod.GET)
	  public ModelAndView showlogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("admin_login");
	    return mav;
	  }
	@RequestMapping(value = "/user_login", method = RequestMethod.GET)
	  public ModelAndView showUserLogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("user_login");
	    return mav;
	  }
	@RequestMapping(value = "/create_account", method = RequestMethod.GET)
	  public ModelAndView showRegAccount(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("create_account");
	    return mav;
	  }
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	  public ModelAndView showLogOut(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("logout");
	    return mav;
	  }
	@RequestMapping(value = "/send_email", method = RequestMethod.GET)
	  public ModelAndView showForgotEmail(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("send_email");
	    return mav;
	  }
	@RequestMapping(value = "/enter_Password", method = RequestMethod.GET)
	  public ModelAndView showForgotPage(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("forgot_password");
	    return mav;
	  }
	@RequestMapping(value = "/ministatement", method = RequestMethod.GET)
	  public ModelAndView showtransmini(HttpServletRequest request, HttpServletResponse response) {
	   List<Transactions>  list = transService.getLastFiveTrans();
	   System.out.println(list.size());
		 ModelAndView mav1 = new ModelAndView("miniStatement");
		 mav1.addObject("translist", list);
	    return mav1;
	  }
	
	@RequestMapping(value = "/statementprocess", method = RequestMethod.POST)
	public ModelAndView viewtrans(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date from=simpleDateFormat.parse(request.getParameter("fromdate"));
		Date to=simpleDateFormat.parse(request.getParameter("todate"));
		List<Transactions>  list = transService.getTrans(from, to);
		 ModelAndView mav = new ModelAndView("BriefStatement");
		 mav.addObject("translist", list);
		// HttpSession session =request.getSession(false);
		// session.setAttribute("ulist", userlist);
		 return mav;
	 }
	
	
	@RequestMapping(value = "/forgot_password", method = RequestMethod.POST)
	public void viewForgotPassword(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		String email=request.getParameter("email");
		SendMail send = new SendMail();
		send.sendmail(email);
		
		 
	 }
	@RequestMapping(value = "/enter_Password_Process", method = RequestMethod.POST)
	public void enterpassword(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		
		String email = request.getParameter("email");
		  String new_password = request.getParameter("new_password");
		  	String confirm_password = request.getParameter("confirm_password");
		  	transService.enterPassword(email, new_password, confirm_password);
		
		 
	 }
	
	
	
}
