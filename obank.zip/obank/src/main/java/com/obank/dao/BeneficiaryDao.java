package com.obank.dao;

import com.obank.model.Beneficiary;

public interface BeneficiaryDao {

	boolean insertBeneficiary(Beneficiary beneficiary);
    Beneficiary getBeneficiary(int baccno);
}
