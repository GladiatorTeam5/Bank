package com.obank.dao;

import com.obank.model.Transactions;

public interface TransDao {
	
	public boolean credit(Transactions transaction);
	
	public boolean debit(Transactions transaction);


}
