package com.obank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.obank.model.Login;
@Repository("userDao")
public class LoginDaoImpl implements LoginDao {

	public Login validateUser(Login user) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();
		Login f =null;
		try{
			f=(Login)em.createQuery("SELECT f FROM Login f WHERE f.custid=:custid and f.lpwd=:lpwd")
		         .setParameter("custid", user.getCustid())
		         .setParameter("lpwd",user.getLpwd())
		         .getSingleResult();
		}
		catch(Exception e) 
		{System.out.println(e); }
		em.close();
		System.out.println(f);
		return f;
	}

	public List<Login> getUsers() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  
		  @SuppressWarnings("unchecked")
			List<Login> users = em.createQuery("SELECT u FROM Login u").getResultList();
		  em.close();
		  return  users;
	}

	public boolean changepwd(int custid ,String lpwd, String npwd) {
		  boolean flag=false;
		  EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  
		  Query query = em.createQuery("update Login u set u.lpwd=:npwd where u.custid=:custid and u.lpwd=:lpwd");
		  query.setParameter("npwd", npwd);
		  query.setParameter("lpwd", lpwd);
		  query.setParameter("custid", custid);
		  em.getTransaction().begin();
		  int r = query.executeUpdate();
		  em.getTransaction().commit();
		  em.close();
		  if(r>0)
			  flag=true;
		  return flag;
	  }

}
