package com.obank.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.obank.model.Transactions;

@Repository("transdao")
public class TransDaoImpl implements TransDao {

public boolean credit(Transactions transaction) {
		
boolean result = false;
		
		try{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(transaction);
			em.getTransaction().commit();
			result = true;
		}
		
		catch(Exception e)
		{
			System.out.println("Error "+e);
		}
		return result;
	
		
	}
	
		
		
		
		
		
		
		
	

	public boolean debit(Transactions transaction) {
		// TODO Auto-generated method stub
boolean result = false;
		
		try{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(transaction);
			em.getTransaction().commit();
			result = true;
		}
		
		catch(Exception e)
		{
			System.out.println("Error "+e);
		}
		return result;
	
	}

}
