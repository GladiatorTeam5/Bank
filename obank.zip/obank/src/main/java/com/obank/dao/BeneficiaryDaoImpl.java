package com.obank.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
/*import org.springframework.dao.DataAccessException;*/
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.obank.model.Accounts;
import com.obank.model.Beneficiary;

@Repository("beneficiaryDAO")
public class BeneficiaryDaoImpl implements BeneficiaryDao {
	@Autowired
	private JdbcTemplate jdbcTemplateObject;
	public boolean insertBeneficiary(Beneficiary beneficiary) {
		
/*boolean result = false;
		
		try{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(beneficiary);
			em.getTransaction().commit();
			result = true;
		}
		
		catch(Exception e)
		{
			System.out.println("Error "+e);
		}
		return result;*/
		/*String sql1 ="select * from Accounts where accno =?";
		int result1 = jdbcTemplateObject.update(sql1,new Object[]{ Accounts.getAccno()});*/
		String sql = "INSERT INTO beneficiary values (?,?,?,?)";
		int result = jdbcTemplateObject.update(sql,new Object[]{ beneficiary.getBaccno(), beneficiary.getBname(), beneficiary.getBnickname(),beneficiary.getAccno()});
		if (result>0){
			System.out.println("added " + beneficiary);
			return true;
		
		}
		else {
			System.out.println("not added" +beneficiary);
			return false;
		}

}
    public Beneficiary getBeneficiary(int baccno)
    {
    	String sql = "Select * from beneficiary where baccno = ?";
		Beneficiary bu =jdbcTemplateObject.query(sql, new Object[]{baccno},new ResultSetExtractor<Beneficiary>(){

			public Beneficiary extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				Beneficiary b = null;
				if (rs.next()){
					b= new Beneficiary();
			  b.setBname(rs.getString(1));
			   b.setBnickname(rs.getString(2));
			   b.setAccno(rs.getInt(3));
				
				}
				return b;
			}
			
			});
		return bu;
		}
    }
