package com.obank.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="beneficiary")
public class Beneficiary {
	@Id
	private int baccno;
	private String bname;
	private String bnickname;
	private int accno;
	public int getBaccno() {
		return baccno;
	}
	public void setBaccno(int baccno) {
		this.baccno = baccno;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBnickname() {
		return bnickname;
	}
	public void setBnickname(String bnickname) {
		this.bnickname = bnickname;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public Beneficiary() {
		super();
	}
	public Beneficiary(int baccno, String bname, String bnickname, int accno) {
		super();
		this.baccno = baccno;
		this.bname = bname;
		this.bnickname = bnickname;
		this.accno = accno;
	}
	@Override
	public String toString() {
		return "Beneficiary [baccno=" + baccno + ", bname=" + bname + ", bnickname=" + bnickname + ", accno=" + accno
				+ "]";
	}
	
	

}
