package com.obank.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transactions")
public class Transactions {
	
	@Id
	private int tid;
	private String tmode;
	private int baccno;
	private double amt;
	private int accno;
	private Date date;
	private String remark;
	private String ttype;
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTmode() {
		return tmode;
	}
	public void setTmode(String tmode) {
		this.tmode = tmode;
	}
	public int getBaccno() {
		return baccno;
	}
	public void setBaccno(int baccno) {
		this.baccno = baccno;
	}
	public double getAmt() {
		return amt;
	}
	public void setAmt(double amt) {
		this.amt = amt;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getTtype() {
		return ttype;
	}
	public void setTtype(String ttype) {
		this.ttype = ttype;
	}
	public Transactions() {
		super();
	}
	public Transactions(int tid, String tmode, int baccno, double amt, int accno, Date date, String remark,
			String ttype) {
		super();
		this.tid = tid;
		this.tmode = tmode;
		this.baccno = baccno;
		this.amt = amt;
		this.accno = accno;
		this.date = date;
		this.remark = remark;
		this.ttype = ttype;
	}
	@Override
	public String toString() {
		return "Transactions [tid=" + tid + ", tmode=" + tmode + ", baccno=" + baccno + ", amt=" + amt + ", accno="
				+ accno + ", date=" + date + ", remark=" + remark + ", ttype=" + ttype + "]";
	}
	
	
	
	

}
