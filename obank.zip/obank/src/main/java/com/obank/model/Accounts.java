package com.obank.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/*create table accounts(
accno number(30) not null primary key,
reqid number(30),
fname varchar(30),
mname varchar(30),
lname varchar(30),

gender varchar(30),
mob number(30),
email varchar(40),
aadhar number(30),
dob date,
address varchar(30),

o_type varchar(30),
o_src varchar(30),
o_inc number(30),
opt_netbank varchar(1), 
iagree varchar(1),
approve varchar(1),
status varchar(1),
balance number(30) default 10000
)*/
@Entity
public class Accounts {
	@Id
	private int accno;
	private int reqid;
	private String fname;
	private String mname;
	private String lname;
	private String gender;
	private int mob;
	private String email;
	private int aadhar;
    private Date date;
	private String address;
	private String o_type;
	private String o_src;
	private int o_inc;
    private char opt_netbank;
    private char iagree;
    private char approve;
    private char status;
    private double balance;
   /* @OneToMany
    private List<Beneficiary>*/
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public int getReqid() {
		return reqid;
	}
	public void setReqid(int reqid) {
		this.reqid = reqid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getMob() {
		return mob;
	}
	public void setMob(int mob) {
		this.mob = mob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAadhar() {
		return aadhar;
	}
	public void setAadhar(int aadhar) {
		this.aadhar = aadhar;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getO_type() {
		return o_type;
	}
	public void setO_type(String o_type) {
		this.o_type = o_type;
	}
	public String getO_src() {
		return o_src;
	}
	public void setO_src(String o_src) {
		this.o_src = o_src;
	}
	public int getO_inc() {
		return o_inc;
	}
	public void setO_inc(int o_inc) {
		this.o_inc = o_inc;
	}
	public char getOpt_netbank() {
		return opt_netbank;
	}
	public void setOpt_netbank(char opt_netbank) {
		this.opt_netbank = opt_netbank;
	}
	public char getIagree() {
		return iagree;
	}
	public void setIagree(char iagree) {
		this.iagree = iagree;
	}
	public char getApprove() {
		return approve;
	}
	public void setApprove(char approve) {
		this.approve = approve;
	}
	public char getStatus() {
		return status;
	}
	public void setStatus(char status) {
		this.status = status;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Accounts() {
		super();
	}
	public Accounts(int accno, int reqid, String fname, String mname, String lname, String gender, int mob,
			String email, int aadhar, Date date, String address, String o_type, String o_src, int o_inc,
			char opt_netbank, char iagree, char approve, char status, double balance) {
		super();
		this.accno = accno;
		this.reqid = reqid;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.gender = gender;
		this.mob = mob;
		this.email = email;
		this.aadhar = aadhar;
		this.date = date;
		this.address = address;
		this.o_type = o_type;
		this.o_src = o_src;
		this.o_inc = o_inc;
		this.opt_netbank = opt_netbank;
		this.iagree = iagree;
		this.approve = approve;
		this.status = status;
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Accounts [accno=" + accno + ", reqid=" + reqid + ", fname=" + fname + ", mname=" + mname + ", lname="
				+ lname + ", gender=" + gender + ", mob=" + mob + ", email=" + email + ", aadhar=" + aadhar + ", date="
				+ date + ", address=" + address + ", o_type=" + o_type + ", o_src=" + o_src + ", o_inc=" + o_inc
				+ ", opt_netbank=" + opt_netbank + ", iagree=" + iagree + ", approve=" + approve + ", status=" + status
				+ ", balance=" + balance + "]";
	}
	
}
