package com.obank.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;

import com.obank.model.Transactions;
import com.obank.service.TransService;



@Controller("transcontroller")
public class TransController {
	
	
	@Autowired
	TransService transService;
	
	@RequestMapping(value ="/transaction" ,method=RequestMethod.GET)
	public ModelAndView showfunds1(HttpServletRequest request , HttpServletResponse response)
	{
		ModelAndView mav = new ModelAndView("transaction");
//		mav.addObject("transaction", new Transactions());
		
		return mav;
	}
	
	
	@RequestMapping(value = "/transaction" ,method=RequestMethod.POST)
	public ModelAndView showfunds2(HttpServletRequest request , HttpServletResponse response) throws ParseException{
		
	
		String tmode = request.getParameter("tmode");
		int  baccno= Integer.parseInt(request.getParameter("b_name"));
		double amt= Double.parseDouble(request.getParameter("amount"));
		int  accno= Integer.parseInt(request.getParameter("a_name"));
		SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-MM-dd");
		Date date = formatter1.parse(request.getParameter("t_date"));
		String remark = request.getParameter("remark");
		String ttype= "c";
		double balance= Double.parseDouble(request.getParameter("balance"));

		Transactions transactions=new Transactions();
		transactions.setTmode(tmode);
		transactions.setBaccno(baccno);
		transactions.setAmt(amt);
		transactions.setAccno(accno);
		transactions.setDate(date);
		transactions.setRemark(remark);
		boolean flag =transService.credit(transactions);
		if(flag)
		{
			ModelAndView mnv = new ModelAndView("success");
		
		
	

		
	/*
			balance=balance-amt;
			mnv.addObject("balance",balance);
			mnv.addObject("status"," amount added");
		*/
	return mnv;
		}
		else
		{
			ModelAndView mnv = new ModelAndView("failure");
			return mnv;

		}
}
	/*@RequestMapping(value = "/transaction" ,method=RequestMethod.POST)
	public ModelAndView debit(HttpServletRequest request , HttpServletResponse response) throws ParseException{
		
	
		String tmode = request.getParameter("tmode");
		int  baccno= Integer.parseInt(request.getParameter("baccno"));
		double amt= Double.parseDouble(request.getParameter("amt"));
		int  accno= Integer.parseInt(request.getParameter("accno"));
		SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-MM-dd");
		Date date = formatter1.parse(request.getParameter("date"));
		String remark = request.getParameter("remark");
		String ttype= request.getParameter("ttype");
		double balance= Double.parseDouble(request.getParameter("balance"));

		Transactions transactions=new Transactions();
		transactions.setTmode(tmode);
		transactions.setBaccno(baccno);
		transactions.setAmt(amt);
		transactions.setAccno(accno);
		transactions.setDate(date);
		transactions.setRemark(remark);
		ModelAndView mnv = new ModelAndView("transaction");
		mnv.addObject("accno",accno);

		if(balance<amt)
		{
			mnv.addObject("status","insufficient balance");
		}
		else
		{
			balance=balance+amt;
			mnv.addObject("balance",balance);
			mnv.addObject("status","amount deducted");
		}
	return mnv;
}*/
}