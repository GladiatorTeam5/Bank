package com.obank.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.obank.model.Beneficiary;
import com.obank.model.Transactions;
import com.obank.service.BeneficiaryService;
import com.obank.service.TransService;

@Controller("beneficiarycontroller")
public class BeneficiaryController {
	
	/*private int baccno;
	private String bname;
	private String bnickname;
	private int accno;*/
	@Autowired
	BeneficiaryService beneficiaryService;
	@RequestMapping(value = "/beneficiary" ,method=RequestMethod.POST)
	public ModelAndView credit(HttpServletRequest request , HttpServletResponse response){
		
		int  baccno= Integer.parseInt(request.getParameter("baccno"));
		String bname = request.getParameter("bname");
		String bnickname = request.getParameter("bnickname");
		int  accno= Integer.parseInt(request.getParameter("accno"));
		
		

		Beneficiary beneficiary=new Beneficiary();
		beneficiary.setBaccno(baccno);
		beneficiary.setBname(bname);
		beneficiary.setBnickname(bnickname);
		beneficiary.setAccno(accno);
		
		return null;
		
	
	}
}
