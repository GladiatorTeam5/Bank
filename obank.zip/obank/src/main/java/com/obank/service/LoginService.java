package com.obank.service;

import java.util.List;

import com.obank.model.Login;

public interface LoginService {
	 Login validateUser(Login user);
	  public List<Login> getUsers();
	  public boolean changepwd(int custid,String lpwd, String npwd);
}
