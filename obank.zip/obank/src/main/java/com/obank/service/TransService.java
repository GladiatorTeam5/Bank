package com.obank.service;

import com.obank.model.Transactions;

public interface TransService {
	
public boolean credit(Transactions transaction);
	
	public boolean debit(Transactions transaction);

}
