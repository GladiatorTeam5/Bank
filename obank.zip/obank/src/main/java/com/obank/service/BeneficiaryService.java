package com.obank.service;

import com.obank.model.Beneficiary;


public interface BeneficiaryService {
	public boolean insertBeneficiary(Beneficiary beneficiary);
}
