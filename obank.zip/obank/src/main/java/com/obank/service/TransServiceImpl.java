package com.obank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.obank.dao.TransDao;
import com.obank.model.Transactions;

@Service("transService")
public class TransServiceImpl implements TransService {
    @Autowired
    TransDao transdao;
    
	/*public boolean credit(Transactions transaction) {
		// TODO Auto-generated method stub
				boolean flag =transdao.credit(transaction);
				System.out.println("transaction credit service called");
				return flag;
	}*/

	public boolean debit(Transactions transaction) {
		boolean flag =transdao.debit(transaction);
		System.out.println("transaction debit service called");
		return flag;
	}

	public boolean credit(Transactions transaction) {
		boolean flag =transdao.credit(transaction);
		System.out.println("transaction credit service called");
		return flag;
		
	}

}
