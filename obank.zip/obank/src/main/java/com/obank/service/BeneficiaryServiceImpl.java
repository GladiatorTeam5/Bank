package com.obank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.obank.dao.BeneficiaryDao;
import com.obank.model.Beneficiary;
@Service("myBeneficiaryService")
public class BeneficiaryServiceImpl implements BeneficiaryService {
	@Autowired
	BeneficiaryDao beneficiarydao;
	public boolean insertBeneficiary(Beneficiary beneficiary) {
		// TODO Auto-generated method stub
		boolean flag =beneficiarydao.insertBeneficiary(beneficiary);
		System.out.println("Beneficiary added");
		return flag;
}


}
