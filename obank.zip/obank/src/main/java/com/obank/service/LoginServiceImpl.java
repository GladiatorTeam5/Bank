package com.obank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.obank.dao.LoginDao;
import com.obank.model.Login;
@Service("userService")
public class LoginServiceImpl implements LoginService {
	 @Autowired
	  public LoginDao loginDao;

	public Login validateUser(Login user) {
		// TODO Auto-generated method stub
		   return loginDao.validateUser(user);
	}

	public List<Login> getUsers() {
		 List<Login>  list = loginDao.getUsers();
		  return list;
	}

	public boolean changepwd(int custid, String lpwd, String npwd) {
		return loginDao.changepwd(custid, lpwd,  npwd);
	}

}
