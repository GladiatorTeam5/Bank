package com.obank.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.obank.model.AppAccounts;
import com.obank.model.Beneficiary;
import com.obank.model.Login;
import com.obank.model.Transactions;
import com.obank.service.LoginService;

@Controller("mycontroller")
public class LoginController {
	@Autowired
	 public LoginService loginService;
	
	
	 @RequestMapping(value = "/login", method = RequestMethod.GET)
	  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("login");
	    mav.addObject("user", new Login());
	    return mav;

}
	  @RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	  public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,   @ModelAttribute Login iuser) {
	    ModelAndView mav = null;
	    
	    Login user = loginService.validateUser(iuser);
	    if (user != null) {
	      mav = new ModelAndView("home");
	     mav.addObject("user", user.getCustid());
	     mav.addObject("accno", user.getAppAccounts().getAccno()); //added
      //session manage
	      
	      HttpSession session= request.getSession();
	      session.setAttribute("user", user);
	     
	    } else {
	      mav = new ModelAndView("login");
	      mav.addObject("message", "Username or Password is wrong!!");
	      
	    }
	    return mav;
	  }
	 @RequestMapping(value = "/changepwd", method = RequestMethod.GET)
	  public ModelAndView changepwd1(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("changepwd");
	    return mav;
	  }
	@RequestMapping(value = "/changepwd", method = RequestMethod.POST)
	  public ModelAndView changepwd2(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        Login user=(Login) session.getAttribute("user");
        String lpwd= request.getParameter("lpwd");
        String npwd= request.getParameter("npwd");
        System.out.println("----------------------------");
        System.out.println(user.getCustid() +" "+lpwd+"  "+npwd);
        boolean flag = loginService.changepwd(user.getCustid(),lpwd,npwd);
        if(flag) {
	       ModelAndView mav = new ModelAndView("changepwd");
	       mav.addObject("message", "Password is successfully updated");
	       return mav;
	  }
        else {
        	ModelAndView mav = new ModelAndView("changepwd");
		       mav.addObject("message", "Password is not updated");
		       return mav;
        }
	}
	
	 @RequestMapping(value = "/add_bene", method = RequestMethod.GET)
	  public ModelAndView getbeneficiary(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("add_bene");
	    mav.addObject("beneficiary", new Beneficiary());
	    return mav;
	 }
		@RequestMapping(value = "/add_bene" ,method=RequestMethod.POST)
		public ModelAndView insert(HttpServletRequest request , HttpServletResponse response,  HttpSession session){


			 Login user=(Login) session.getAttribute("user");
			 System.out.println(user);
			String  baccno= request.getParameter("baccno");
			String bname = request.getParameter("bname");
			String bnickname = request.getParameter("bnickname");
		    long bid =new Date().getTime();
			Beneficiary beneficiary=new Beneficiary();
			beneficiary.setBaccno(baccno);
			beneficiary.setBname(bname);
			beneficiary.setBnickname(bnickname);
			AppAccounts appAccounts = new AppAccounts();
			appAccounts.setAccno(user.getAppAccounts().getAccno());
			
			//beneficiary.setAppAccounts(appAccounts);
			beneficiary.setAccno(user.getAppAccounts().getAccno());
			beneficiary.setBid(bid);
			System.out.println("beneficiary:"+beneficiary);
			
			boolean flag = loginService.insertBeneficiary(beneficiary);
			
				if (flag){
					ModelAndView mav = new ModelAndView("success");
					mav.addObject("status","thanks you are registered"); 
					
			     
			      return mav;
					}
					else {
						ModelAndView mav = new ModelAndView("add_bene");
						mav.addObject("status","Beneficiary doesn't exist in our bank");
						return mav;
				 	}
			    
			
		
		}
		
		@RequestMapping(value = "/success", method = RequestMethod.GET)
		  public ModelAndView success(HttpServletRequest request, HttpServletResponse response) {
		    ModelAndView mav = new ModelAndView("success");
		    return mav;
		  }
	
		
		 @RequestMapping(value = "/transaction", method = RequestMethod.GET)
		  public ModelAndView gettransaction(HttpServletRequest request, HttpServletResponse response) {
		    ModelAndView mav = new ModelAndView("transaction");
		   
		    return mav;
		 }
		 
			@RequestMapping(value = "/transfer" ,method=RequestMethod.POST)
			public ModelAndView doFundTrans(HttpServletRequest request , HttpServletResponse response,  HttpSession session){
				 Login user=(Login) session.getAttribute("user");
				 String accno = user.getAppAccounts().getAccno();
				 
				 String baccno = request.getParameter("baccno");
				 String remark = request.getParameter("remark");
				 int amount = Integer.parseInt(request.getParameter("amount"));
				 boolean flag = loginService.doFundTrans(accno, baccno, amount,remark);
				 if (flag)
				 {
					 Transactions t = new Transactions();
					 
					ModelAndView mnv = new ModelAndView("transaction"); 
					/*mnv.addObject("tid",t.getTid());
					mnv.addObject("tmode", t.getTmode());
					mnv.addObject("baccno", t.getBaccno());
					mnv.addObject("ttype", t.getTtype());
					mnv.addObject("dot",t.getDot());*/
					//mnv.addObject("t",t);
					mnv.addObject("msg"," Transaction successful");
					return mnv;
					/* Transactions t=(Transactions) session.getAttribute("t");
						List<Transactions> list = loginService.doFundTrans(t.getTid(), t.getTmode(), t.getBaccno(), t.getTtype(),t.getDot());
					    ModelAndView mav = new ModelAndView("viewbene");
					    mav.addObject("blist", list);*/
				 }
				 else {
					 ModelAndView mnv = new ModelAndView("transaction");
					 mnv.addObject("msg","Unsuccessful Transaction");
					 return mnv;
				 }
				
				
			}
		

			@RequestMapping(value = "/view_bene", method = RequestMethod.GET)
			  public ModelAndView getmybeneficiary(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
				Login user=(Login) session.getAttribute("user");
				List<Beneficiary> list = loginService.getMyBeneficiary(user.getAppAccounts().getAccno());
			    ModelAndView mav = new ModelAndView("viewbene");
			    mav.addObject("blist", list);
			    return mav;
			}
			
			
	  
	}

