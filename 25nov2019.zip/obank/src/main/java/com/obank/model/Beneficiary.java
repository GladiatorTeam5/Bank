package com.obank.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="beneficiary")
public class Beneficiary {
	@Id
  //  @GeneratedValue(strategy=GenerationType.AUTO)
	private long bid;//change to string
	private String baccno;
	private String bname;
	private String bnickname;
	//private String accno;
	
   /* @ManyToOne
	@JoinColumn(name="accno")
	private AppAccounts appAccounts;*/
	private String accno;

		public long getBid() {
			return bid;
		}

		public void setBid(long bid) {
			this.bid = bid;
		}

		public String getBaccno() {
			return baccno;
		}

		public void setBaccno(String baccno) {
			this.baccno = baccno;
		}

		public String getBname() {
			return bname;
		}

		public void setBname(String bname) {
			this.bname = bname;
		}

		public String getBnickname() {
			return bnickname;
		}

		public void setBnickname(String bnickname) {
			this.bnickname = bnickname;
		}

	/*	public AppAccounts getAppAccounts() {
			return appAccounts;
		}

		public void setAppAccounts(AppAccounts appAccounts) {
			this.appAccounts = appAccounts;
		}*/

		
		@Override
		public String toString() {
			return "Beneficiary [bid=" + bid + ", baccno=" + baccno + ", bname=" + bname + ", bnickname=" + bnickname
					+ ", appAccounts=" + accno + "]";
		}

		public String getAccno() {
			return accno;
		}

		public void setAccno(String accno) {
			this.accno = accno;
		}

		public Beneficiary() {
			super();
		}

	
}