package com.obank.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "appaccounts")
public class AppAccounts {
	@Id
	private String accno;
	private String reqid;
	private String fname;
	private String mname;
	private String lname;
	private String gender;
	private String mob;
	private String email;
	private String aadhar;

	@Temporal(TemporalType.DATE)
	private Date dob;
	private String dob_fname;
	private String address;
	private String o_type;
	private String o_inc;
	private String image;
	private String opt_netbank;
	private String iagree;
	private String approve;
	private String status;
	private int balance;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "accno")
	private Login login;
	
	@OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="accno")
	private List<Beneficiary> beneficiary=new ArrayList<Beneficiary>();
	public Login getLogin() {
		return login;
	}
	public void setLogin(Login login) {
		this.login = login;
	}
	public String getAccno() {
		return accno;
	}
	public void setAccno(String accno) {
		this.accno = accno;
	}
	public String getReqid() {
		return reqid;
	}
	public void setReqid(String reqid) {
		this.reqid = reqid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAadhar() {
		return aadhar;
	}
	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getDob_fname() {
		return dob_fname;
	}
	public void setDob_fname(String dob_fname) {
		this.dob_fname = dob_fname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getO_type() {
		return o_type;
	}
	public void setO_type(String o_type) {
		this.o_type = o_type;
	}
	public String getO_inc() {
		return o_inc;
	}
	public void setO_inc(String o_inc) {
		this.o_inc = o_inc;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getOpt_netbank() {
		return opt_netbank;
	}
	public void setOpt_netbank(String opt_netbank) {
		this.opt_netbank = opt_netbank;
	}
	public String getIagree() {
		return iagree;
	}
	public void setIagree(String iagree) {
		this.iagree = iagree;
	}
	public String getApprove() {
		return approve;
	}
	public void setApprove(String approve) {
		this.approve = approve;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public AppAccounts() {
		super();
	}
	public List<Beneficiary> getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(List<Beneficiary> beneficiary) {
		this.beneficiary = beneficiary;
	}
	@Override
	public String toString() {
		return "AppAccounts [accno=" + accno + ", reqid=" + reqid + ", fname=" + fname + ", mname=" + mname + ", lname="
				+ lname + ", gender=" + gender + ", mob=" + mob + ", email=" + email + ", aadhar=" + aadhar + ", dob="
				+ dob + ", dob_fname=" + dob_fname + ", address=" + address + ", o_type=" + o_type + ", o_inc=" + o_inc
				+ ", image=" + image + ", opt_netbank=" + opt_netbank + ", iagree=" + iagree + ", approve=" + approve
				+ ", status=" + status + ", balance=" + balance + ", login=" + login + ", beneficiary=" + beneficiary
				+ "]"+getBeneficiary().size();
	}
	
	
}
