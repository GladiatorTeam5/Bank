package com.obank.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="net_banking")
public class Login {

	
	@Id	
	private String custid;
	private String lpwd;
	private String tpwd;
	private String email;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@OneToOne
	@JoinColumn(name = "accno")
	private AppAccounts appAccounts;
	
	public AppAccounts getAppAccounts() {
		return appAccounts;
	}
	public void setAppAccounts(AppAccounts appAccounts) {
		this.appAccounts = appAccounts;
	}
	public String getCustid() {
		return custid;
	}
	public void setCustid(String custid) {
		this.custid = custid;
	}
	public Login() {
		super();
	}
	public String getLpwd() {
		return lpwd;
	}
	public void setLpwd(String lpwd) {
		this.lpwd = lpwd;
	}
	public String getTpwd() {
		return tpwd;
	}
	public void setTpwd(String tpwd) {
		this.tpwd = tpwd;
	}
	
}
