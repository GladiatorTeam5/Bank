package com.obank.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.obank.dao.LoginDao;
import com.obank.model.Beneficiary;
import com.obank.model.Login;
import com.obank.model.Transactions;


@Service("userService")
public class LoginServiceImpl implements LoginService {
	 @Autowired
	  public LoginDao loginDao;

	  @Transactional
	public Login validateUser(Login user) {
		// TODO Auto-generated method stub
		   return loginDao.validateUser(user);
	}

	  @Transactional
	public List<Login> getUsers() {
		 List<Login>  list = loginDao.getUsers();
		  return list;
	}

	  @Transactional
	public boolean changepwd(String custid, String lpwd, String npwd) {
		return loginDao.changepwd(custid, lpwd,  npwd);
	}
	  
	  
	 @Transactional
	public boolean insertBeneficiary(Beneficiary beneficiary) {
		
		boolean flag =loginDao.insertBeneficiary(beneficiary);
		System.out.println("Beneficiary added");
		return flag;
}
	
/*	public Beneficiary validateBene(Beneficiary beneficiary) {
		return loginDao.validateBene(beneficiary);
		
	}*/

	
	 @Transactional
	public List<Beneficiary> getMyBeneficiary(String accno){
		return loginDao.getMyBeneficiary(accno);
	}
	@Transactional
	public boolean doFundTrans(String accno,String baccno,int amount,String remark){
		return loginDao.doFundTrans(accno, baccno, amount,remark);
	}


	 }
	 
	
	

		
		
	
	
	

