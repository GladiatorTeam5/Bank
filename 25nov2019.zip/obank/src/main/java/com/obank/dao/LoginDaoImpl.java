package com.obank.dao;

/*import java.sql.ResultSet;*/
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.obank.model.AppAccounts;
import com.obank.model.Beneficiary;
import com.obank.model.Login;

import com.obank.model.Transactions;
@Repository("userDao")
public class LoginDaoImpl implements LoginDao {
	
	@PersistenceContext
	EntityManager em;

	public Login validateUser(Login user) {
		/*EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();*/
		Login f =null;
		try{
			f=(Login)em.createQuery("SELECT f FROM Login f WHERE f.custid=:custid and f.lpwd=:lpwd")
		         .setParameter("custid", user.getCustid())
		         .setParameter("lpwd",user.getLpwd())
		         .getSingleResult();
		}
		catch(Exception e) 
		{System.out.println(e); }
		/*em.close();*/
		System.out.println(f);
		return f;
	}

	public List<Login> getUsers() {
		/*EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  */
		  @SuppressWarnings("unchecked")
			List<Login> users = em.createQuery("SELECT u FROM Login u").getResultList();
		/*  em.close();*/
		  return  users;
	}

	public boolean changepwd(String custid ,String lpwd, String npwd) {
		  boolean flag=false;
		/*  EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  */
		  Query query = em.createQuery("update Login u set u.lpwd=:npwd where u.custid=:custid and u.lpwd=:lpwd");
		  query.setParameter("npwd", npwd);
		  query.setParameter("lpwd", lpwd);
		  query.setParameter("custid", custid);
		/*  em.getTransaction().begin();*/
		  int r = query.executeUpdate();
		 /* em.getTransaction().commit();
		  em.close();*/
		  if(r>0)
			  flag=true;
		  return flag;
	  }
	
	public boolean insertBeneficiary(Beneficiary beneficiary) {
		 boolean flag=false;
		    try {
		    	Beneficiary b = new Beneficiary();
		   Query q1 = em.createQuery("SELECT a.accno from AppAccounts a where a.accno=:baccno");
		    q1.setParameter("baccno", b.getAccno());
		    List<String> blist = q1.getResultList();
		    String baccno = blist.get(0);
		    if (baccno != null){
		    
		 	em.persist(beneficiary);
			System.out.println("added " +beneficiary);
			flag= true;
		    }
		}
		    catch(Exception e) { System.out.println("Error:"+e);  }
		   // em.close();
		    return flag;
		}

	
	 public List<Beneficiary> getMyBeneficiary(String accno){
		 Query q1 = em.createQuery("From Beneficiary b WHERE b.accno=:accno");
		 q1.setParameter("accno", accno);
		 List<Beneficiary> list = q1.getResultList();
		 return list;
	 
	 }

	
	 
	 public boolean doFundTrans(String accno,String baccno,int amount,String remark){
		 
		 boolean flag = false;
		 try{
			 
			Query q1 = em.createQuery("SELECT a.balance from AppAccounts a where a.accno=:accno");
			q1.setParameter("accno", accno);
			List<Integer> alist = q1.getResultList();
			int abal =(int) alist.get(0);
			 abal =(int)(abal - amount);
			System.out.println("balance of my acc  "+abal);
			
			System.out.println("second query after this ======");
			Query q2 = em.createQuery("SELECT a.balance from AppAccounts a where a.accno=:baccno");
			q2.setParameter("baccno", baccno);
			List<Integer> blist = q2.getResultList();
			int bbal = (int)blist.get(0);
			 bbal =(int)(bbal + amount);
			System.out.println("balance of to acc  "+bbal);
			System.out.println(bbal);
		Query query1 = em.createQuery("update AppAccounts a set a.balance=:balance where a.accno=:accno");
		 query1.setParameter("balance",abal);
		 query1.setParameter("accno",accno);
		 
		 Query query2 = em.createQuery("update AppAccounts a set a.balance=:balance where a.accno=:baccno");
		 query2.setParameter("balance",bbal);
		 query2.setParameter("baccno",baccno);
		 
		 int r3 = query1.executeUpdate();
		 int r4 = query2.executeUpdate();
		 if(r3 ==1 && r4==1){
			  flag=true;
			 
			  
			
			 if (r3==1){
				 Transactions t = new Transactions();
				 long tid =(new Date().getTime());
				  t.setTid(tid);
				  t.setMat_inst("none");
				  t.setTmode("online");
				 t.setAccno(accno);
				 t.setBaccno(baccno);
				 t.setAmt(amount);
				 t.setRemark(remark);
				 t.setTtype("D");
				 t.setDot(new Date());
				 em.persist(t);
				/* Query q = em.createQuery("SELECT all from Transactions t where t.accno=:accno");
				 t = (Transactions) q1.setParameter("accno", accno).getSingleResult();*/
			 }
			 if(r4==1){
				 Transactions t = new Transactions();
				 long tid = (new Date().getTime());
				  t.setTid(tid);
				  t.setMat_inst("none");
				  t.setTmode("online");
				 t.setAccno(baccno);
				 t.setBaccno(accno);
				 t.setAmt(amount);
				 t.setRemark(remark);
				 t.setTtype("C");
				 t.setDot(new Date());
				 em.persist(t);
			 }
			
			 
	
			  }
		 }
		 
		 
		 catch(Exception e) { System.out.println("Error:"+e);  }
		 
		 return flag;
		 
	 }

	

	}
		
		
		
	


