package com.obank.dao;

import java.util.List;

import com.obank.model.Beneficiary;
import com.obank.model.Login;
import com.obank.model.Transactions;


public interface LoginDao {
	 Login validateUser(Login user);
	  public List<Login> getUsers();
	  public boolean changepwd(String custid,String lpwd, String npwd );
	  public boolean insertBeneficiary(Beneficiary beneficiary);
	
	
	  
	  public List<Beneficiary> getMyBeneficiary(String accno);
	  public boolean doFundTrans(String accno,String baccno,int amount, String remark);
	 
	  
}


