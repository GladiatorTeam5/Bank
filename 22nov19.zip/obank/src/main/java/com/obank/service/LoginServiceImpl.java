package com.obank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.obank.dao.LoginDao;
import com.obank.model.Beneficiary;
import com.obank.model.Login;
@Service("userService")
public class LoginServiceImpl implements LoginService {
	 @Autowired
	  public LoginDao loginDao;

	  @Transactional
	public Login validateUser(Login user) {
		// TODO Auto-generated method stub
		   return loginDao.validateUser(user);
	}

	  @Transactional
	public List<Login> getUsers() {
		 List<Login>  list = loginDao.getUsers();
		  return list;
	}

	  @Transactional
	public boolean changepwd(int custid, String lpwd, String npwd) {
		return loginDao.changepwd(custid, lpwd,  npwd);
	}
	  
	  
	  LoginDao beneficiarydao;
@Transactional
	public boolean insertBeneficiary(Beneficiary beneficiary) {
		
		boolean flag =beneficiarydao.insertBeneficiary(beneficiary);
		System.out.println("Beneficiary added");
		return flag;
}
	}

		
		
	
	
	

