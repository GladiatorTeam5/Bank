package com.obank.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.obank.model.Beneficiary;
import com.obank.model.Login;
import com.obank.service.LoginService;

@Controller("mycontroller")
public class LoginController {
	@Autowired
	 public LoginService loginService;
	
	
	 @RequestMapping(value = "/login", method = RequestMethod.GET)
	  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("login");
	    mav.addObject("user", new Login());
	    return mav;

}
	  @RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	  public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,   @ModelAttribute Login iuser) {
	    ModelAndView mav = null;
	    Login user = loginService.validateUser(iuser);
	    if (user != null) {
	      mav = new ModelAndView("changepwd");
/*	     mav.addObject("custid", user.getCustid());
*/	      //session manage
	      HttpSession session= request.getSession();
	      session.setAttribute("account number", iuser.getAccno());
	      session.setAttribute("custid", iuser.getCustid());
	    } else {
	      mav = new ModelAndView("login");
	      mav.addObject("message", "Username or Password is wrong!!");
	    }
	    return mav;
	  }
	 @RequestMapping(value = "/changepwd", method = RequestMethod.GET)
	  public ModelAndView changepwd1(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("changepwd");
	    return mav;
	  }
	@RequestMapping(value = "/changepwd", method = RequestMethod.POST)
	  public ModelAndView changepwd2(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        int custid=(Integer) session.getAttribute("custid");
        String lpwd= request.getParameter("lpwd");
        String npwd= request.getParameter("npwd");
        System.out.println("----------------------------");
        System.out.println(custid +" "+lpwd+"  "+npwd);
        boolean flag = loginService.changepwd(custid,lpwd,npwd);
        if(flag) {
	       ModelAndView mav = new ModelAndView("changepwd");
	       mav.addObject("message", "Password is successfully updated");
	       return mav;
	  }
        else {
        	ModelAndView mav = new ModelAndView("changepwd");
		       mav.addObject("message", "Password is not updated");
		       return mav;
        }
	}
	/* @RequestMapping(value = "/beneficiary", method = RequestMethod.GET)
	  public ModelAndView insertbeneficiary(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("login");
	    mav.addObject("user", new Login());
	    return mav;

}
	  @RequestMapping(value = "/beneficiary", method = RequestMethod.POST)
	  public ModelAndView getbeneficiary(HttpServletRequest request, HttpServletResponse response,   @ModelAttribute Login iuser) {
	    ModelAndView mav = null;
	    Login user = loginService.validateUser(iuser);
	    if (user != null) {
	      mav = new ModelAndView("success");
	     mav.addObject("custid", user.getCustid());
	      //session manage
	      HttpSession session= request.getSession();
	    session.setAttribute("account number", iuser.getAccno());
	      session.setAttribute("custid", user.getCustid());
	    } else {
	      mav = new ModelAndView("failure");
	      mav.addObject("message","no enough data");
	    }
	    return mav;
	  }
	  */
	
	 @RequestMapping(value = "/add_bene", method = RequestMethod.GET)
	  public ModelAndView getbeneficiary(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("add_bene");
	    mav.addObject("beneficiary", new Beneficiary());
	    return mav;
	 }
		@RequestMapping(value = "/add_bene" ,method=RequestMethod.POST)
		public ModelAndView insertbeneficiary(HttpServletRequest request , HttpServletResponse response){
			//ModelAndView mav = new ModelAndView("beneficiary");
			int  baccno= Integer.parseInt(request.getParameter("baccno"));
			String bname = request.getParameter("bname");
			String bnickname = request.getParameter("bnickname");
			int  accno= Integer.parseInt(request.getParameter("accno"));
			
			Beneficiary beneficiary=new Beneficiary();
			beneficiary.setBaccno(baccno);
			beneficiary.setBname(bname);
			beneficiary.setBnickname(bnickname);
			beneficiary.setAccno(accno);
			
			ModelAndView mav = new ModelAndView("success");
			
			return mav;
		
		}
	}

