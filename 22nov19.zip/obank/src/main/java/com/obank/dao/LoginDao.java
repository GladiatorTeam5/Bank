package com.obank.dao;

import java.util.List;

import com.obank.model.Beneficiary;
import com.obank.model.Login;

public interface LoginDao {
	 Login validateUser(Login user);
	  public List<Login> getUsers();
	  public boolean changepwd(int custid,String lpwd, String npwd );
	  boolean insertBeneficiary(Beneficiary beneficiary);
	  Beneficiary getBeneficiary(int baccno);
	 
	  
}


