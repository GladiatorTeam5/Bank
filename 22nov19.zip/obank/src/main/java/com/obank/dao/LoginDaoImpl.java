package com.obank.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.obank.model.Beneficiary;
import com.obank.model.Login;
@Repository("userDao")
public class LoginDaoImpl implements LoginDao {
	
	@PersistenceContext
	EntityManager em;

	public Login validateUser(Login user) {
		/*EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();*/
		Login f =null;
		try{
			f=(Login)em.createQuery("SELECT f FROM Login f WHERE f.custid=:custid and f.lpwd=:lpwd")
		         .setParameter("custid", user.getCustid())
		         .setParameter("lpwd",user.getLpwd())
		         .getSingleResult();
		}
		catch(Exception e) 
		{System.out.println(e); }
		/*em.close();*/
		System.out.println(f);
		return f;
	}

	public List<Login> getUsers() {
		/*EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  */
		  @SuppressWarnings("unchecked")
			List<Login> users = em.createQuery("SELECT u FROM Login u").getResultList();
		/*  em.close();*/
		  return  users;
	}

	public boolean changepwd(int custid ,String lpwd, String npwd) {
		  boolean flag=false;
		/*  EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  */
		  Query query = em.createQuery("update Login u set u.lpwd=:npwd where u.custid=:custid and u.lpwd=:lpwd");
		  query.setParameter("npwd", npwd);
		  query.setParameter("lpwd", lpwd);
		  query.setParameter("custid", custid);
		/*  em.getTransaction().begin();*/
		  int r = query.executeUpdate();
		 /* em.getTransaction().commit();
		  em.close();*/
		  if(r>0)
			  flag=true;
		  return flag;
	  }
	
	private JdbcTemplate jdbcTemplateObject;
	public boolean insertBeneficiary(Beneficiary beneficiary) {
		String sql = "INSERT INTO beneficiary values (?,?,?,?)";
		int result = jdbcTemplateObject.update(sql,new Object[]{ beneficiary.getBaccno(), beneficiary.getBname(), beneficiary.getBnickname(),beneficiary.getAccno()});
		if (result>0){
			System.out.println("added " + beneficiary);
			return true;
		
		}
		else {
			System.out.println("not added" +beneficiary);
			return false;
		}

	}

	public Beneficiary getBeneficiary(int baccno) {
		String sql = "Select * from beneficiary where baccno = ?";
		Beneficiary bu =jdbcTemplateObject.query(sql, new Object[]{baccno},new ResultSetExtractor<Beneficiary>(){

			public Beneficiary extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				Beneficiary b = null;
				if (rs.next()){
					b= new Beneficiary();
			  b.setBname(rs.getString(1));
			   b.setBnickname(rs.getString(2));
			   b.setAccno(rs.getInt(3));
				
				}
				return b;
			}
			
			});
		return bu;
		}
		
	}


